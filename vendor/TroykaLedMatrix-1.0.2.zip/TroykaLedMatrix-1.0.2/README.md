Светодиодная матрица 8×8 (Troyka-модуль)
========================================

Библиотека для Arduino, позволяющая выводить пиксели, символы и изображения на [светодиодную матрицу 8×8](http://amperka.ru/product/troyka-led-matrix).

Установка библиотеки
====================

В Arduino IDE выберите пункт меню «Скетч» → «Импортировать библиотеку» →
«Добавить библиотеку…». В появившемся окне выберите скачаный архив с
библиотекой. Установка завершена.

Подробности и примеры работы — [в статье на Амперка / Вики](http://wiki.amperka.ru/%D0%BF%D1%80%D0%BE%D0%B4%D1%83%D0%BA%D1%82%D1%8B:troyka-led-matrix)

Led Matrix 8×8 dots
===================

This Arduino library relates to [Led Matrix 8×8](http://amperka.com/products/troyka-led-matrix).
It allows to show pixels, symbols, and pictures on the screen.

Installation
============

Open Arduino IDE. Choose "Sketch" → "Import library" → "Add library…".
In appeared window choose downloaded zip.
