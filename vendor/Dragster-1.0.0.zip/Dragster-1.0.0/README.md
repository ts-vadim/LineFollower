Dragster
========

Библиотека Arduino для [Драгстера](http://amperka.ru/product/dragster).

Установка библиотеки
====================

В Arduino IDE выберите пункт меню «Скетч» → «Импортировать библиотеку» →
«Добавить библиотеку…». В появившемся окне выберите скачаный архив с
библиотекой. Установка завершена.

This Arduino library relates to [Dragster](http://amperka.com/product/dragster).

Installation
============

Open Arduino IDE. Choose "Scketch" → "Iport library" → "Add library…".
In appeared window choose downloaded zip.