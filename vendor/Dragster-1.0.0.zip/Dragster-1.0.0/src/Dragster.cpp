/*
 * This file is a part of Dragster car set library.
 *
 *
 * © Amperka LLC (https://amperka.com, dev@amperka.com)
 * 
 * Author: Harry Morgan <morgan@amperka.ru>
 * Refactored by: Yury Botov (by@amperka.com)
 * License: GPLv3, all text here must be included in any redistribution.
 */

#include "Dragster.h"

Dragster::Dragster() {
    // default parameters for 3-4 Ohm motors
    setMotorLimits(MMAX_3_OHM, MMIN_DEFAULT, MMIN_DEFAULT);
}

Dragster::Dragster(byte motorMax) {
    setMotorLimits(motorMax, MMIN_DEFAULT, MMIN_DEFAULT);
}

Dragster::Dragster(byte motorMax, byte motorMinForward, byte motorMinBackward) {
    setMotorLimits(motorMax, motorMinForward, motorMinBackward);
}

void Dragster::setMotorLimits(byte motorMax, byte motorMinForward, byte motorMinBackward) {
    _motorMax = motorMax;
    _motorMinForward = motorMinForward;
    _motorMinBackward = motorMinBackward;
}

void Dragster::begin() {
    pinMode(DRAGSTER_MOTOR_PIN1, OUTPUT);
    pinMode(DRAGSTER_MOTOR_PIN2, OUTPUT);
    pinMode(DRAGSTER_MOTOR_PIN3, OUTPUT);
    pinMode(DRAGSTER_MOTOR_PIN4, OUTPUT);

    pinMode(DRAGSTER_BUTTON_PIN, INPUT);
    pinMode(DRAGSTER_LED_PIN, OUTPUT);
}

void Dragster::begin(int direction) {
    if (direction & SWAP_LEFT) {
        _swappedLeft = 0;
    }
    if (direction & SWAP_RIGHT) {
        _swappedRight = 1;
    }
    begin();
}

void Dragster::drive(int left, int right) {
    driveMotor(left, _swappedLeft, DRAGSTER_MOTOR_PIN2, DRAGSTER_MOTOR_PIN4);
    driveMotor(right, _swappedRight, DRAGSTER_MOTOR_PIN1, DRAGSTER_MOTOR_PIN3);
}

void Dragster::driveF(float left, float right) {
    drive((int)(left * 255.0), (int)(right * 255.0));
}

void Dragster::encodersBegin(void (*left)(), void (*right)()) {
    attachInterrupt(DRAGSTER_LEFT_ENCODER_INTPIN, left, CHANGE);
    attachInterrupt(DRAGSTER_RIGHT_ENCODER_INTPIN, right, CHANGE);
}

bool Dragster::readButton() {
    return digitalRead(DRAGSTER_BUTTON_PIN);
}

void Dragster::led(int state) {
    digitalWrite(DRAGSTER_LED_PIN, state);
}

void Dragster::driveMotor(int speed, int swapped, byte dir, byte drv) {
    if (swapped)
        speed = -speed;
    if (speed == 0) {
        analogWrite(drv, 0);
    } else if (speed > 0) {
        digitalWrite(dir, HIGH);
        analogWrite(drv, map(speed, 0, 255, _motorMinForward, _motorMax));
    } else {
        digitalWrite(dir, LOW);
        analogWrite(drv, map(-speed, 0, 255, _motorMinBackward, _motorMax));
    }
}
