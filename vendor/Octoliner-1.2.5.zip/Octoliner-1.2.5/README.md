Octoliner
=========

Библиотека Arduino для [модуля 8 датчиков линии (Zelo-модуль)](http://amperka.ru/product/zelo-folow-line-sensor).

Установка библиотеки
====================

В Arduino IDE выберите пункт меню «Скетч» → «Импортировать библиотеку» →
«Добавить библиотеку…». В появившемся окне выберите скачаный архив с
библиотекой. Установка завершена.

This Arduino library relates to [8 line sensors module (Zelo-module)](http://amperka.ru/product/zelo-folow-line-sensor).

Installation
====================

Open Arduino IDE. Choose "Scketch" → "Iport library" → "Add library…".
In appeared window choose downloaded zip.
